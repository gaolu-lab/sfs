package gaolu38.com;

import androidx.appcompat.app.AppCompatActivity;

public abstract class BaseActivity extends AppCompatActivity {

    void initView(){};

    void initData(){};

}
